This is for the first deployment in git and git hub  by giving url to everyone
